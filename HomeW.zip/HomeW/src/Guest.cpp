#include "../include/Guest.h"
#include<iostream>



//display Guest informations
void Guest::display(){
    std::cout << "___________________________________" << std::endl;
    std::cout << "Guest Name : "<<p_name<< std::endl;
    std::cout << "___________________________________"<< std::endl;
    std::cout << "Score : "<<p_score << std::endl;
    std::cout << "___________________________________" << std::endl;
    std::cout << "Turn : "<<p_tour<< std::endl;
    std::cout << "___________________________________" << std::endl;
    std::cout << "Accuracy : "<<p_accuracy <<"%"<< std::endl;
    std::cout << "___________________________________" << std::endl;

}
//ask the gest name
string Guest::ask(){
    cout<< "What is your name ?:";
    cin>>p_name;
    return p_name;
}

string Guest::setName(string name){
    p_name=name;
    return p_name;
}
string Guest::getName(){
    return p_name;
}
