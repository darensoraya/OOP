#include "../include/Admin.h"
#include<iostream>
#include"../Player.h"

Admin::Admin()
{
    a_choice="";
}
//display Admin informations
void Admin::display(){
    std::cout << "___________________________________" << std::endl;
    std::cout << "Player Admin" << std::endl;
    std::cout << "___________________________________"<< std::endl;
    std::cout << "Score : "<<p_score << std::endl;
    std::cout << "___________________________________" << std::endl;
    std::cout << "Turn : "<<p_tour<< std::endl;
    std::cout << "___________________________________" << std::endl;
    std::cout << "Accuracy : "<<p_accuracy <<"%"<< std::endl;
    std::cout << "___________________________________" << std::endl;

}
//choose if you play alone our with a guest
string Admin::choose(){

    cin>>a_choice;
    return a_choice;
}

