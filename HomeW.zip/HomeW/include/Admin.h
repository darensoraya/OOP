#ifndef ADMIN_H
#define ADMIN_H
#include "../Player.h"
#include <string>
//Inheritance
class Admin : public Player
{
    public:
        Admin();
        string choose();
        void display();



    private:
    string a_choice;
};

#endif // ADMIN_H
