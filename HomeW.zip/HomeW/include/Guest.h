#ifndef GUEST_H
#define GUEST_H
#include "../Player.h"
#include <string>

//Inheritance
class Guest : public Player
{
    public:

        string ask();
        void display();

    string setName(string name);
    string getName();

    private:
    string p_name;
};

#endif // GUEST_H
