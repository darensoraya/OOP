#include <iostream>
#include <string>
#include <cstdlib>
#include"Player.h"


using namespace std;
Player::Player(){
    p_tour=0;//number of turn
    p_accuracy=0;//each player have accuracy
}

void Player::display(){
//polymorphisme
}


float Player::setScore(float score){
    p_score=score;
    return p_score;
}
float Player::setTour(float tour){
    p_tour=tour;
    return p_tour;
}
float Player::setAccuracy(float accuracy){
    p_accuracy=accuracy;
    return p_accuracy;
}
//Overloads
//Smaller
bool Player::more_than_small(Player const& a)const{
    return p_score < a.p_score;
}
bool Player::operator<(Player const& a){
    return more_than_small(a);
}
//Bigger
bool Player::bigger(Player const& a)const{
    return p_score > a.p_score;
}
bool Player::operator>(Player const& a){
    return bigger(a);
}

