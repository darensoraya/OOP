#include <iostream>
#include <string>
#include <time.h>
#include "Timer.h"
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include "Player.h"
#include "include/Guest.h"
#include "include/Admin.h"
#include <vector>


using namespace std;

//fixed the choosing word
string melangerLettres(string mot)
{
   string melange;
   int position(0);

   //As long as we haven't extracted all the letters of the word
   while (mot.size() != 0)
   {
      //We choose a letter number at random in the word
      position = rand() % mot.size();
      //Add the letter to the mixed word
      melange += mot[position];
      // We remove this letter from the mystery word
       // So as not to take it a second time
        mot.erase(position, 1);
    }

   //We return the mixed word
   return melange;
}

//take yhe word in the file dico
string take_word(int a, bool b){
        std::fstream file;
        string word;
        file.open("dico.txt",ios::in);
        int wordNum=0;
        while(!b){
            file>>word;
            if(wordNum==a){
            b=true;
        }
        wordNum++;
    }
    return word;
}

//calculating the score according to the turn
int score_turn(int i){
    int answer;
if(i%2==0){
        //score of the guest
    answer=1;
}else{
    //score of the Administrator
    answer=0;
}
    return answer;
}

int main()
{

    string answer,ans;
    unsigned long second = 30;
    float score_a=0;//score of administrator
    float score_g=0;// score of the guest
    int tour=1;//turn
    int x;//take seconds
    Player p;//player
    Guest g;//gest
    Admin a;//administrator
    Timer tim;//timer


    //1- administrator choose if he play with someone
    while(ans != "y" && ans != "n"){
    cout<< "Do you want to play with someone ?[y/n] :";
        ans=a.choose();
    }

    tim.start();

    while(true){
        if(tim.elapsedTime() >= second){

            break;
        }
        else{
            //yes case
            if(ans=="y"){
            //1.a- we ask the name of the guest
                g.ask();
        bool atword=false;
      do{
         string motMystere, motMelange, motUtilisateur;//mystry word, mixed word, the word entered by the player
        srand(time(0));

            //1.b- we chek if the value is between 0-20
        int choice(21);
           while(choice > 20 || choice < 0){
            cout<<"Please enter a number between 0 and 20 : ";
            cin>>choice;
            }

        //1.c- taking the word in the file and mixed it
        motMystere = take_word(choice,atword);
        motMelange = melangerLettres(motMystere);
        //1.d- taking the player proposition
        cout << endl << "What is the word ? " << motMelange << endl;
        cin >> motUtilisateur;

        //conditions
      if (motUtilisateur == motMystere)
      {
         cout << "Right !" << endl;

         if(score_turn(tour)==1){
        score_g+=1;
         }else{
         score_a+=1;
         }

      }
      else
      {
         cout << "Wrong !" << endl;
         if(score_turn(tour)==1){
        score_g+=0;
         }else{
         score_a+=0;
         }


      }

      /////////////////////
      tour++;
    }while(tour<7);

        //1.f- after the 6th turn we print the result and the winner according to the score
        a.setScore(score_a);
        g.setScore(score_g);
        a.setTour(tour/2);
        g.setTour(tour/2);
        a.setAccuracy(100*(score_a/2));
        g.setAccuracy(100*(score_g/2));
        a.display();
        g.display();
        if(g<a){
            cout<<"**************************"<<endl;
            cout<<"Admin is the WINNER !!!!!!"<<endl;
            cout<<"**************************"<<endl;
        }else if(g>a){
            cout<<"**************************"<<endl;
            cout<<g.getName()<<" is the WINNER !!!!!!"<<endl;
            cout<<"**************************"<<endl;
        }else{
            cout<<"**************************"<<endl;
            cout<<"   Drawn match !!!!!!"<<endl;
            cout<<"**************************"<<endl;
        }

      //////////////////////////////////////////////////////////////////

    }else{
        x = tim.elapsedTime();
        float score=0;
         do{

        string motMystere, motMelange, motUtilisateur;
        srand(time(0));


    string word_2;
    bool atword_2=false;
    int choice_2(21);
      while(choice_2 > 20 || choice_2 < 0){
        cout<<"Please enter a number between 0 and 20 : ";
        cin>>choice_2;
    }

    motMystere=word_2;
    motMystere = take_word(choice_2,atword_2);
    motMelange = melangerLettres(motMystere);
        cout<<"Timer :"<<tim.elapsedTime()<<endl;
        cout << endl << "What is the word ? " << motMelange << endl;
        cin >> motUtilisateur;

        if (motUtilisateur == motMystere)
        {
         cout << "Right !" << endl;
         cout<<"Timer :"<<tim.elapsedTime()<<endl;
         score+=1;
      }
      else
      {
         cout << "Wrong !" << endl;
         cout<<"Timer :"<<tim.elapsedTime()<<endl;
      }
      tour++;

    }while(tim.elapsedTime() <= second);

    a.setScore(score);
    a.setTour(tour-1);
    a.setAccuracy((score/(tour-1))*100);

     string const nomFichier("score.txt");
     ofstream monFlux(nomFichier.c_str(),ios::app);

    if(monFlux)
    {
        monFlux << ((score/(tour-1))*100) << endl;

    }
    vector<float>tab;
    ifstream monFichier("score.txt");

    if(monFichier){
        string ligne;
        while(getline(monFichier,ligne)){
            tab.push_back(stof(ligne));
        }
    }
    //printing the result of the administrator with the higher score
    a.display();
    auto it = *max_element(begin(tab), end(tab));
    cout<<"*************************"<<endl;
    cout<<"Higth Score : "<<it<<endl;
    cout<<"*************************"<<endl;

   cout<<"Timer :"<<tim.elapsedTime()<<endl;
    }
        }
    }



    return 0;
}
