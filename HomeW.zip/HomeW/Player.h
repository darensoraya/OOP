#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED
using namespace std;
class Player{

    public:

     Player();
    void display();
    float setScore(float score);
    float setTour(float tour);
    float setAccuracy(float accuracy);
    bool operator<(Player const& a);
    bool more_than_small(Player const& a)const;
    bool operator>(Player const& a);
    bool bigger(Player const& a)const;


//Abstraction
    protected:

    float p_score;
    float p_tour;
    float p_accuracy;
};


#endif // PLAYER_H_INCLUDED
